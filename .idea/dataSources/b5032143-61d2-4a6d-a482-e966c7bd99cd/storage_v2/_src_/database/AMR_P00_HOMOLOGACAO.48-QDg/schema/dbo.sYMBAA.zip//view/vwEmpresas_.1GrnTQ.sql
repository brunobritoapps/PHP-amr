
CREATE VIEW [dbo].[vwEmpresas_] AS
SELECT M0_CODIGO AS Cod_Empresa,
        M0_NOME AS Nome_Empresa,
        M0_CODFIL AS Cod_Filial,
        M0_FILIAL AS Nome_Filial
FROM P12_PRODUCAO..SM0010
go

