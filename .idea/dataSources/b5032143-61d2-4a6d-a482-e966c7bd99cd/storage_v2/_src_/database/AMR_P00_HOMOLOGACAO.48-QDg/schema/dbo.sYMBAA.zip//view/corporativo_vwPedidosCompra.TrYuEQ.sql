CREATE VIEW [dbo].[vwPedidosCompra] AS
SELECT * 
FROM [P12_PRODUCAO].[dbo].[SC7010]
go

