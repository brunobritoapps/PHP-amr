CREATE VIEW [dbo].[vwFuncionarios] AS
SELECT * 
FROM [P12_PRODUCAO].[dbo].[SA2010]
go

